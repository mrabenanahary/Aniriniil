#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec  3 00:06:00 2019

@author: mialy94

=================================================================
= Auteur : Mialy RABENANAHARY
= 
= foormulae.py
= 
= Module contenant toutes les fonctions qui emploient des formules
= mathématiques non-physiques (transformée de Fourier, séries, approximations, ...)
= 
=
=================================================================
"""
